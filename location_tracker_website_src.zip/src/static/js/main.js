// Main JavaScript for Location Tracker Website

document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const locationDataElement = document.getElementById('location-data');
    const refreshButton = document.getElementById('refresh-location');
    const clearButton = document.getElementById('clear-location');
    const mapElement = document.getElementById('map');
    
    // Function to format location data into HTML
    function formatLocationData(data) {
        if (!data || !data.location) {
            return '<p>No location data available.</p>';
        }
        
        const location = data.location;
        
        let html = '<div class="location-info">';
        
        // IP Address
        html += `<div><strong>IP Address</strong>${location.ip || 'Unknown'}</div>`;
        
        // City, Region, Country
        if (location.city || location.region || location.country) {
            html += `<div><strong>Location</strong>${location.city || ''}, ${location.region || ''}, ${location.country || ''}</div>`;
        }
        
        // Postal Code
        if (location.postal) {
            html += `<div><strong>Postal Code</strong>${location.postal}</div>`;
        }
        
        // Coordinates
        if (location.loc) {
            html += `<div><strong>Coordinates</strong>${location.loc}</div>`;
        }
        
        // Organization
        if (location.org) {
            html += `<div><strong>Network</strong>${location.org}</div>`;
        }
        
        // Timezone
        if (location.timezone) {
            html += `<div><strong>Timezone</strong>${location.timezone}</div>`;
        }
        
        // Street information (if available)
        if (location.street) {
            html += `<div><strong>Street</strong>${location.street}</div>`;
        }
        
        html += '</div>';
        
        // Add source information
        if (data.source) {
            html += `<p class="data-source">Source: ${data.source}</p>`;
        }
        
        return html;
    }
    
    // Function to load map based on coordinates
    function loadMap(coordinates) {
        if (!coordinates) {
            mapElement.innerHTML = '<p>No coordinates available to display map.</p>';
            return;
        }
        
        // For a real implementation, you would integrate with a mapping API like Google Maps or Leaflet
        // This is a placeholder that shows the coordinates
        const [lat, lng] = coordinates.split(',');
        
        mapElement.innerHTML = `
            <div style="padding: 20px; text-align: center;">
                <h3>Map Placeholder</h3>
                <p>In a production environment, this would display an interactive map centered at:</p>
                <p><strong>Latitude:</strong> ${lat}, <strong>Longitude:</strong> ${lng}</p>
                <div style="margin-top: 20px; border: 2px dashed #ccc; height: 200px; display: flex; align-items: center; justify-content: center;">
                    <p>Map would be displayed here</p>
                </div>
            </div>
        `;
    }
    
    // Function to fetch location data from API
    async function fetchLocationData() {
        locationDataElement.innerHTML = '<p>Loading location data...</p>';
        locationDataElement.classList.add('loading');
        
        try {
            const response = await fetch('/api/location/track');
            const data = await response.json();
            
            locationDataElement.classList.remove('loading');
            
            if (data.success) {
                locationDataElement.innerHTML = formatLocationData(data);
                
                // Load map if coordinates are available
                if (data.location && data.location.loc) {
                    loadMap(data.location.loc);
                }
            } else {
                locationDataElement.innerHTML = `<p class="error">Error: ${data.error || 'Failed to retrieve location data'}</p>`;
            }
        } catch (error) {
            locationDataElement.classList.remove('loading');
            locationDataElement.innerHTML = `<p class="error">Error: ${error.message || 'Failed to connect to the server'}</p>`;
        }
    }
    
    // Function to check for existing location cookie
    async function checkExistingLocation() {
        try {
            const response = await fetch('/api/location/current');
            const data = await response.json();
            
            if (data.success) {
                locationDataElement.innerHTML = formatLocationData(data);
                
                // Load map if coordinates are available
                if (data.location && data.location.loc) {
                    loadMap(data.location.loc);
                }
            } else {
                // If no cookie exists, fetch new location data
                fetchLocationData();
            }
        } catch (error) {
            // If error occurs, try to fetch new location data
            fetchLocationData();
        }
    }
    
    // Function to clear location cookie
    async function clearLocationCookie() {
        try {
            const response = await fetch('/api/location/clear', {
                method: 'POST'
            });
            const data = await response.json();
            
            if (data.success) {
                locationDataElement.innerHTML = '<p>Location cookie cleared successfully.</p>';
                mapElement.innerHTML = '<p>Map will appear here once location is loaded...</p>';
            } else {
                locationDataElement.innerHTML = `<p class="error">Error: ${data.error || 'Failed to clear location cookie'}</p>`;
            }
        } catch (error) {
            locationDataElement.innerHTML = `<p class="error">Error: ${error.message || 'Failed to connect to the server'}</p>`;
        }
    }
    
    // Event Listeners
    refreshButton.addEventListener('click', fetchLocationData);
    clearButton.addEventListener('click', clearLocationCookie);
    
    // Initial check for existing location cookie
    checkExistingLocation();
});
